﻿namespace $safeprojectname$.Context
{
    public class DbContextData
    {


    }
}
