﻿using Flunt.Notifications;

namespace $safeprojectname$.ValueObjects
{
    public abstract class ValueObject : Notifiable
    {

    }
}
