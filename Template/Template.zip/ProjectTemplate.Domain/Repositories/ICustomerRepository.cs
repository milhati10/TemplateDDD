﻿using $ext_projectname$.Domain.Entities;

namespace $safeprojectname$.Repositories
{
    public interface ICustomerRepository : IRepository<Customer>
    {

    }
}
