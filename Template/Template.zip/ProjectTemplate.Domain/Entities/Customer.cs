﻿using $ext_projectname$.Domain.ValueObjects;

namespace $safeprojectname$.Entities
{
    public class Customer : Entity
    {
        public Name Name { get; private set; }
    }
}
